---
id: 1118
title: 'Principios básicos en el desarrollo de software'
date: '2016-07-03T20:50:34+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/118-revision-v1/'
permalink: '/?p=1118'
---

A la hora de diseñar y desarrollar software, es importante tener presente una serie de *principios de diseño fundamentales y básicos* que todo programador debería conocer y aplicar para desarrollar código limpio y de calidad.   
 [<span aria-label="Sigue leyendo Principios básicos en el desarrollo de software">(más…)</span>](https://josecuellar.net/?p=1118#more-1118)