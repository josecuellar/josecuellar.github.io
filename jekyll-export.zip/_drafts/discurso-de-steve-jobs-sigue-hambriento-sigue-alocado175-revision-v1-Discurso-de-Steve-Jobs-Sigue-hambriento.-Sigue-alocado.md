---
id: 882
title: 'Discurso de Steve Jobs: «Sigue hambriento. Sigue alocado.»'
date: '2016-06-01T12:55:55+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/175-revision-v1/'
permalink: '/?p=882'
---

Hace cinco años, [Steve Jobs](http://es.wikipedia.org/wiki/Steve_Jobs) resumió su vida en quince minutos en un discurso para la Universidad de Standford.

> Sé que el contenido de este post informa de algo no reciente, pasado. Aunque influencias así, deberían estar presentes en el día a día, en la vida de todas aquellas personas que se arriesgan, luchan y sueñan por todo aquello en lo que creen. No me cansaré nunca de escucharlo...

   
  
 Reflexionando las palabras de [Steve Jobs](http://es.wikipedia.org/wiki/Steve_Jobs), resulta casi inevitable pensar: Hay que tener suerte... Por supuesto, lo creo. Igual que creo que sin trabajo y sacrificio, la suerte, es inútil. Además [Steve Jobs](http://es.wikipedia.org/wiki/Steve_Jobs), la buscó y la encontró. Estar dispuesto al cambio y a seguir las ideas en las que crees, es una buena manera de iniciar tu búsqueda.   
  
 [<span aria-label="Sigue leyendo Discurso de Steve Jobs: «Sigue hambriento. Sigue alocado.»">(más…)</span>](https://josecuellar.net/?p=882#more-882)