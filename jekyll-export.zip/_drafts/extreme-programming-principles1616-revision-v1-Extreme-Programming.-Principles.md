---
id: 1806
title: 'Extreme Programming. Principles'
date: '2019-09-24T18:21:22+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/1616-revision-v1/'
permalink: '/?p=1806'
---

Principles may guide your team´s practices, but these are the prinnciples that guide XP:

<center>![](https://josecuellar.net/wp-content/uploads/xpprinciples.png)</center> [<span aria-label="Sigue leyendo Extreme Programming. Principles">(más…)</span>](https://josecuellar.net/?p=1806#more-1806)