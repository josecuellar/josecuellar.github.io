---
id: 1600
title: 'Algunos comentarios de los libros que he leído los últimos meses'
date: '2017-04-03T09:32:16+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/1489-revision-v1/'
permalink: '/?p=1600'
---

No podemos permitirnos el lujo de caer en la monotonía técnica y dejarnos llevar por las mismas formas de hacer las cosas una y otra vez y de la manera que ya conocemos. Necesitamos hacer un esfuerzo en **seguir aprendiendo y mantenernos actualizados** siempre que nos sea posible. Si te apasiona la programación y todo lo que le rodea, como en mi caso, no te supondrá ningún esfuerzo sino todo lo contrario. El aprendizaje continuo o [lifelong learning](https://en.wikipedia.org/wiki/Lifelong_learning). Entre tantos y tantos libros interesantes, lo importante es elegir bien cuales leer y cuales de ellos se convertirán en nuestros consejeros. Me gustaría compartir algunos comentarios de los libros que he leído los últimos meses y que os recomiendo leer. [<span aria-label="Sigue leyendo Algunos comentarios de los libros que he leído los últimos meses">(más…)</span>](https://josecuellar.net/?p=1600#more-1600)