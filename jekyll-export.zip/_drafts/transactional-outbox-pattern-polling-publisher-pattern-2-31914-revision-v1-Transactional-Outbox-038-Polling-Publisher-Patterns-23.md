---
id: 2048
title: 'Transactional Outbox &#038; Polling Publisher Patterns (2/3)'
date: '2020-05-05T20:56:30+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/1914-revision-v1/'
permalink: '/?p=2048'
---

A lo largo del tiempo las bases de datos *NoSQL* han ido mejorado sus características para ofrecernos *ACID* según el tipo (**Single Row, Single Shard o Distrituded**):

<figure class="wp-block-image size-large is-resized">![](https://josecuellar.net/wp-content/uploads/2020/04/image-21-1024x312.png)<figcaption>*Modern databases offer distributed ACID, Sid Choudhury*</figcaption></figure> [<span aria-label="Sigue leyendo Transactional Outbox & Polling Publisher Patterns (2/3)">(más…)</span>](https://josecuellar.net/?p=2048#more-2048)