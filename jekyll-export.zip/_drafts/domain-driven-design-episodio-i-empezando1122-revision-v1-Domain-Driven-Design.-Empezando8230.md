---
id: 2036
title: 'Domain-Driven Design. Empezando&#8230;'
date: '2020-05-03T09:00:20+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/1122-revision-v1/'
permalink: '/?p=2036'
---

Estoy inmerso en la lectura de "*Implementing Domain-Driven Design*" de Vaughn Vernon. Llevo algunos pocos capítulos y he decidido, a modo de seguimiento y aprendizaje, empezar a escribir una serie de post para compartir con la comunidad algunas reseñas de lo que creo interesante. Siéntete libre de hacer tus comentarios :)

<center>![](http://josecuellar.net/wp-content/uploads/ddd.jpg)</center>> El diseño no es sólo cómo se ve o cómo se siente. El Diseño es cómo funciona. Steve Jobs

 [<span aria-label="Sigue leyendo Domain-Driven Design. Empezando…">(más…)</span>](https://josecuellar.net/?p=2036#more-2036)