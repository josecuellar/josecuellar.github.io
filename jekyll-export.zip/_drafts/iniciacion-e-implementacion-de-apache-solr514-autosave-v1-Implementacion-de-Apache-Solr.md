---
id: 891
title: 'Implementación de Apache Solr'
date: '2016-06-01T14:20:35+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/514-autosave-v1/'
permalink: '/?p=891'
---

Desde hace algunos meses he tenido la oportunidad de realizar tareas de implementación, configuración, adaptación y transicion de consultas SQL sobre una aplicación web de alto rendimiento mediante Apache Solr.

<center>![](http://josecuellar.net/wp-content/uploads/solr.jpg)</center>Este hecho me ha permitido acercarme a la tecnología y dar mis primeros pasos en esta magnífica herramienta de búsqueda en la que cada día aprendo algo nuevo. [<span aria-label="Sigue leyendo Implementación de Apache Solr">(más…)</span>](https://josecuellar.net/?p=891#more-891)