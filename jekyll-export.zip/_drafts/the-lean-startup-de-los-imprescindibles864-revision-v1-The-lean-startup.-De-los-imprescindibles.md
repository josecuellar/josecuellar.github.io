---
id: 928
title: 'The lean startup. De los imprescindibles'
date: '2016-06-04T22:02:38+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/864-revision-v1/'
permalink: '/?p=928'
---

El método Lean Startup supone un nuevo enfoque que se está adoptando en todo el mundo para cambiar la forma en que las empresas crean y lanzan sus productos. Eric Ries define una startup como una organización dedicada a crear algo bajo condiciones de incertidumbre extrema. Prácticas pensadas para ayudar a los emprendedores a incrementar las probabilidades de crear una startup con éxito. No es una fórmula matemática infalible, sino una filosofía empresarial innovadora que ayuda a los emprendedores a escapar de las trampas del pensamiento empresarial tradicional. [<span aria-label="Sigue leyendo The lean startup. De los imprescindibles">(más…)</span>](https://josecuellar.net/?p=928#more-928)