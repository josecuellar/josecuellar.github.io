---
id: 1117
title: 'Principios básicos en el desarrollo de software'
date: '2016-07-03T20:52:56+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/118-autosave-v1/'
permalink: '/?p=1117'
---

A la hora de diseñar y desarrollar software, es importante tener presente una serie de *principios de diseño fundamentales y básicos* que todo programador debería conocer y aplicar para desarrollar código limpio y de calidad.   
 [<span aria-label="Sigue leyendo Principios básicos en el desarrollo de software">(más…)</span>](https://josecuellar.net/?p=1117#more-1117)