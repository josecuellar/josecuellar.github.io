---
id: 1085
title: 'Retrospectivas más Kaizen'
date: '2016-06-20T22:04:33+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/1078-autosave-v1/'
permalink: '/?p=1085'
---

Las retrospectivas en SCRUM son reuniones que se realizan tras finalizar el sprint (después de la demo o revisión del sprint y antes de la planificación). La duración de la reunión depende de la duración del sprint: normalmente 1 hora, por semana de sprint. El equipo identifica problemas, posibles medidas para solucionarlos y valoran aquellos hábitos o forma de trabajo que el equipo desea mantener: en la reunión de retrospectiva, se exponen, plantean y reflexionan los tres grupos. Surgiendo medidas o acciones necesarias para mejorar en posteriores sprints. **Se trata de evolucionar la forma de trabajar mediante la mejora continua** hacia la excelencia, incrementando la productividad progresivamente. Además, fomenta la cohesión y la confianza del equipo. En la reunión, el equipo contesta tres preguntas: **¿Qué ha funcionado bien?****¿Qué debemos mejorar?****¿Que acciones tomamos?** [<span aria-label="Sigue leyendo Retrospectivas más Kaizen">(más…)</span>](https://josecuellar.net/?p=1085#more-1085)