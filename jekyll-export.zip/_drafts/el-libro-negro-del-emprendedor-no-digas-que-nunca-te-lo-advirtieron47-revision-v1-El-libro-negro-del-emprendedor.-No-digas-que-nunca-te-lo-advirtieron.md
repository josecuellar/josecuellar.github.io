---
id: 753
title: 'El libro negro del emprendedor. No digas que nunca te lo advirtieron'
date: '2016-05-30T21:20:09+00:00'
author: Jose
excerpt: "Hace unos días acabé la lectura de <i>El libro negro del emprendedor. No digas que nunca te lo advirtieron.</i> De <b>Fernando Trías de Bes</b>. Un libro de fácil y rápida lectura. \r\n\r\nSe lo recomiendo a todas aquellas personas que quieran emprender una idea, a quienes la emprendieron, fracasaron y quieran volver a intentarlo, o simplemente quieran informarse de las verdades y riesgos que existen a la hora de emprender.\r\n"
layout: revision
guid: 'http://www.josecuellar.net/47-revision-v1/'
permalink: '/?p=753'
---

Hace unos días acabé la lectura de *El libro negro del emprendedor. No digas que nunca te lo advirtieron.* De **Fernando Trías de Bes**. Un libro de fácil y rápida lectura. Se lo recomiendo a todas aquellas personas que quieran emprender una idea, a quienes la emprendieron, fracasaron y quieran volver a intentarlo, o simplemente quieran informarse de las verdades y riesgos que existen a la hora de emprender.

<center>![El libro negro del emprendedor. No digas que nunca te lo advirtieron.](http://www.josecuellar.net/wp-content/uploads/librosymanuales/14fcf_front.png)</center> [<span aria-label="Sigue leyendo El libro negro del emprendedor. No digas que nunca te lo advirtieron">(más…)</span>](https://josecuellar.net/?p=753#more-753)