---
id: 1956
title: 'Transactional Outbox Pattern &#038; Polling Publisher Pattern (2/3)'
date: '2020-04-24T20:18:18+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/1914-revision-v1/'
permalink: '/?p=1956'
---

A lo largo del tiempo las bases de datos *NoSQL* han ido mejorado sus características para ofrecernos *ACID* según el tipo (**Single Row, Single Shard o Distrituded**):

<figure class="wp-block-image size-large is-resized">![](https://josecuellar.net/wp-content/uploads/2020/04/image-21-1024x312.png)<figcaption>*Modern databases offer distributed ACID, Sid Choudhury*</figcaption></figure> [<span aria-label="Sigue leyendo Transactional Outbox Pattern & Polling Publisher Pattern (2/3)">(más…)</span>](https://josecuellar.net/?p=1956#more-1956)