---
id: 1804
title: 'Extreme Programming. Corollary Practices'
date: '2019-09-24T18:20:19+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/1635-revision-v1/'
permalink: '/?p=1804'
---

This practices are dificult or dangerous to implement before completing the preliminary work of the primary practices. If you begin deploying daily, for example, without getting the defect rate down close to zero, you will have a disaster on your hands. Trust your nose about what you need to improve next. ![](https://josecuellar.net/wp-content/uploads/xppractices.JPG) [<span aria-label="Sigue leyendo Extreme Programming. Corollary Practices">(más…)</span>](https://josecuellar.net/?p=1804#more-1804)