---
id: 1065
date: '2016-06-12T18:40:07+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/973-revision-v1/'
permalink: '/?p=1065'
---

Las opciones o métodos recomendados en entornos ágiles son:

### Estimar en puntos de historia abstractos

 Desvincular totalmente el tiempo liberándolo de la presión mediante puntos de historia. No se trata de averiguar cuanto se tardará en hacer una historia de usuario o saber su alcance exacto, sino simplemente saber el tamaño aproximado "a priori", para intuir cuánto esfuerzo relativo deberá aplicar el equipo. Javier Garzas utiliza la metáfora del viaje en su post [¿Por qué utilizamos Puntos Historia para estimar y no horas?](http://www.javiergarzas.com/2015/06/puntos-historia-para-estimar-y-no-horas.html): La distancia a recorrer es la misma para todos, pero no sabemos el tiempo exacto que tardaremos en llegar. Dichos puntos de historia se representan con la [sucesión de Fibonacci](https://es.wikipedia.org/wiki/Sucesi%C3%B3n_de_Fibonacci) utilizando la técnica de [planning pocker](https://es.wikipedia.org/wiki/Planning_poker) para evitar influencias entre los miembros del equipo. > El consenso del equipo es mucha más fácil y relajado. Fomentando el diálogo y el aprendizaje continuo.

 <u>Las ventajas más destacadas que nos aportarán las métricas mediante los puntos de historia son:</u>- Disponer de una "**velocidad** de crucero" aproximada de desarrollo permitiendo tener mayor aproximación con las historias de usuario que el equipo va a comprometerse a desarrollar en el sprint.
- Establecer un **mejor y más realista sprint goal** y un margen o "buffer" para contemplar las deudas técnicas e imprevistos (fuegos, incidencias e imprevistos).
- Reflejar en **gráficas [burndown](https://es.wikipedia.org/wiki/Burn_down_chart) o el [burn-up](http://jmbeas.es/guias/burn-up-chart/)**.
- Fuente de información de posibles mejoras en las retrospectivas del equipo.
- Anticipar/organizar pair programming u otras técnicas de colaboración.
- Detectar aquellas historias de usuario que no siguen los principios [INVEST](https://en.wikipedia.org/wiki/INVEST_(mnemonic)). En la gran mayoría de casos: con tamaño excesivo (hay que dividirla) o con dependencias (hay que replantearla).
- Perfecto indicador para [product owners](https://www.mountaingoatsoftware.com/agile/scrum/product-owner) y stakeholders.
 
### Estimar mediante tallas (XS, S, M, L, XL, XXL)

 Nos aporta todas las ventajas de los puntos de historia, excepto las métricas. También se utiliza planning pocker. ### Movimiento [\#NoEstimates](https://twitter.com/search?q=%23NoEstimates&src=tyah)

 Liderado por [Woody Zuill](https://twitter.com/woodyzuill) y [Neil Killick](https://neilkillick.wordpress.com/): estimar no es necesario. Sus defensores argumentan que es imposible estimar cuando todavía no sabemos o entendemos la solución. El desarrollo de software es impredecible. Fijar el alcance exacto (ya sea en tiempo o esfuerzo) de los proyectos es imposible. Incluso si lo fuera, no es deseable, ya que un enfoque de este tipo limita el cambio durante el proyecto, limita un diseño emergente, los requisitos cambiantes y la innovación. Lectura recomendada: [Estimation is Evil - The Estimation Obsession](https://pragprog.com/magazines/2013-02/estimation-is-evil) **Entonces, ¿Estimamos?** En mi opinión, depende del nivel de "maduración" del equipo y su evolución. > Cuando se implanta un marco de trabajo ágil en una organización, o por primera vez un equipo comienza su primer sprint, aconsejo que el cambio sea **en base al modelo teórico** que propone dicho marco de trabajo. Sin ningún tipo de adaptación/modificación preestablecida. Evitando las presuposiciones y recomendaciones de terceros, **ya que lo que puede funcionar a un equipo, puede no funcionar en otro**. De forma natural y a lo largo de los sprints, nacerán propuestas y decisiones en el equipo para aplicar técnicas o modificar las existentes. Estas decisiones o propuestas se hablan en las retrospectivas, dando lugar a la mejora continua. De modo que **inicialmente**, mi recomendación es **estimar en puntos de historia** utilizando la sucesión de Fibonacci mediante planning pocker.

 Con el tiempo, el aprendizaje, la madurez y la habilidad/experiencia aprendida y compartida, el equipo decidirá de forma natural que ya no precisa de métricas por conocer su forma intrínseca de trabajar u organizarse: simplificando así a la estimación mediante tallas. Para más adelante, muy probablemente, unirse al movimiento #NoEstimates. > En mi opinión, la estimación, es el camino de aprendizaje y madurez perfecto para dejar de usarla.