---
id: 1866
title: 'Inteligencia emocional, Kaizen y Lean UX: libros recomendados'
date: '2019-11-19T22:23:46+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/895-revision-v1/'
permalink: '/?p=1866'
---

En los últimos meses he tenido la oportunidad de leerme algunos libros. Quiero compartir con vosotros una pequeña reseña por cada uno, por si os pudiese servir de ayuda en la elección de vuestra próxima lectura. [<span aria-label="Sigue leyendo Inteligencia emocional, Kaizen y Lean UX: libros recomendados">(más…)</span>](https://josecuellar.net/?p=1866#more-1866)