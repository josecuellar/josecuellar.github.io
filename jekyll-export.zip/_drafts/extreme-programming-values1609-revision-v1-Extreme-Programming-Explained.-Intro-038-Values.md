---
id: 1614
title: 'Extreme Programming Explained. Intro &#038; Values'
date: '2017-11-25T19:15:41+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/1609-revision-v1/'
permalink: '/?p=1614'
---

> Driving is not about getting the car going in the right direction. Driving is about constantly paying attention, making a little correction this way, a little correction that way.

 XP is about social change. It is about letting go of habits and patterns that were adaptive in the past, but now get in the way of us doing our best work. It is about giving up the defenses that protect us but interfere with our productivity. It may leave us feeling exposed. It is about writing great code that is really good for business. Need both technique and good relationships to be successful. XP is a stye of software development focusing on excellent application of programming techniques, clear communication, and teamwork. [<span aria-label="Sigue leyendo Extreme Programming Explained. Intro & Values">(más…)</span>](https://josecuellar.net/?p=1614#more-1614)