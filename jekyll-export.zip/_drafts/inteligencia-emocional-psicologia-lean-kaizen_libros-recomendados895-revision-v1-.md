---
id: 956
date: '2016-06-07T19:03:57+00:00'
author: Jose
layout: revision
guid: 'http://josecuellar.net/895-revision-v1/'
permalink: '/?p=956'
---

En los últimos meses he tenido la oportunidad de leerme algunos libros. Quiero compartir con vosotros una pequeña reseña por cada uno por si os pudiese servir de ayuda. En mi opinión, algunos más recomendables que otros. ![](http://josecuellar.net/wp-content/uploads/emqvsf.jpg) Betseller internacional. Historia de un abogado obsesionado con el éxito y el trabajo, sufre un infarto causándole una crisis espiritual. Tras recuperarse decide viajar por Himalaya para conocer una antiquísima cultura de hombres sabios. Allí descubre un modo y filosofía de vida más esclarecedor, así como un método que le permite liberar todo su potencial y vivir con pasión, determinación y paz. Uniendo la sabiduría espiritual de Oriente con los principios del éxito occidentales enfocados al consumismo y materialismo. Tras el viaje vuelve y enseña todo lo aprendido a su viejo joven compañero de oficio para evitar que siga sus pasos.

> Muchos valores y consejos inspiradores que invitan continuamente a la reflexión, otros obvios expresados mediante metáforas y ejemplos interesantes. Los diálogos están muy poco trabajados, se nota que la importancia reside únicamente en el mensaje, sin pulir nada del resto. Recomendable, aunque demasiada sabiduría oriental puede llegar a empalagar. **7/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/elqntc.jpg) Relata la vida de Black, un joven que sufrió mucho con la muerte de sus padres. En esas circunstancias conoce a Tommy Flinn, un personaje particular que sirve de guía para encaminar la vida de Black convirtiéndose en su mentor. Flinn, junto con cuatro maestros; Anna, Ty Boyd, Jackson Chan y Jet; le enseñan filosofías para el trabajo y para la vida. A través de Flinn, Robin Sharma comparte su fórmula y visión para el éxito profesional y personal. Los mejores métodos que Robin Sharma resume y adapta, después de más de quince años como asesosor de liderazgo en empresas como Microsoft, Nike, Unilever o la NASA. > Recorre varios tipos dispares de personalidad en cada maestro para expresar ejemplos de vivencias y valores. Defienden que todos tenemos capacidad de liderazgo que hay que despertar con una correcta actitud. Del mismo modo que el anterior, no esperes grandes diálogos o descripciones detalladas, simplemente presta atención al mensaje. Recomendable para ayudar a mejorar la actitud, automotivación y capacidades de liderazgo. **6/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/dalecarnegie.jpg) Dale Carnegie, escritor norteamericano, uno de los pioneros en el género de los libros de relaciones públicas, ventas y autoyuda. Publicado por primera vez en 1936, se han vendido 15 millones de copias en todo el mundo. Previamente, y durante más de 20 años, había dado a conocer sus ideas en ponencias y cursos, e incluso publicó dos libros sobre cómo hablar en público, pero nunca alcanzaron la importancia de esta obra, que, junto con las siguientes del autor, dieron lugar al programa de formación en relaciones personales que lleva su nombre. > Francamente y sencillamente genial. Libro para digerir despacio y repasarlo de vez en cuando. Técnicas y reglas empleadas en diferentes contextos y situaciones en la vida en las relaciones personales y profesionales. Análisis de las ventajas que supone aplicarlas para beneficio de los implicados. El control emocional con consejos en cada situación. Ejemplos reales y datos biográficos de grandes personajes como Abraham Lincoln. Un complemento perfecto a inteligencia emocional de Daniel Goleaman. **Léelo y te harás un favor. 9/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/ie.jpg) Gran indispensable. En un estudio reciente con los mejores trabajadores de distintas empresas, desde puestos base a puestos ejecutivos, el factor más importante para el buen desempeño no fue el coeficiente intelectual, sino la inteligencia emocional. De todas las competencias requeridas para ejecutar adecuadamente las funciones de los trabajos, el 67% eran competencias emocionales. Abundantes investigaciones demuestra que las habilidades emocionales son susceptibles de aprenderse y perfeccionarse a lo largo de la vida. Goleman no inventó este término, sin embargo, fue introducido por primera vez por Wayne Payne y más tarde desarrollado por los psicólogos Peter Salovey y John D. en la década de los 90. Sin embargo, fue popularizado a partir de este best seller. > El concepto que explica la fusión entre el intelecto y los sentimientos: la inteligencia emocinal. Los instintos naturales e impulsos espontáneos nos niegan la oportunidad de aplicar el pensamiento racional en ciertas situaciones. El libro nos dará pautas y nos aportará ejemplos para entender hasta qué punto y cómo podemos asumir el control de las emociones que necesitamos para llegar a nuestros objetivos y mejorar las relaciones que nos rodean. Relatos de experimentos psicológicos nos ayudarán a entender cómo funciona nuestro cerebro. Además del profesional, aplicado en varios ámbitos como la educación, sanidad y pareja sentimental. Totalmente recomendable. De aquellos libros que cuando los lees te arrepientes de no haberlo hecho antes. **8/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/eadnalv.jpg) La debilidad emocional puede darse con los años si no se sigue unas pautas de pensamientos positivos. Rafael Santandreu, psicólogo barcelonés explica que muchos de los problemas emocionales actuales son causa de una mala filosofía de vida. El arte de no amargarse la vida cuenta que nuestros principales trastornos emocionales que nos inducen a la debilidad emocional podrían calificarse de "terribilitis" y "necesitis". > Como mejorar nuestra relación con nosotros mismos y superar todos aquellos pensamientos y creencias negativas que nos amargan la vida sin necesidad ni motivo real. Me ha gustado el enfoque de sus métodos reflejado en los casos de varios de sus pacientes y sus evoluciones. **6/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/kaizen.jpg) El Kaizen, traducido del japonés como “mejora”, supone un proceso de mejora constante e incremental desarrollado con pequeños pasos acumulativos, que pueden parecer insignificantes en un principio, pero que sostenidos de manera constante en el tiempo pueden alcanzar resultados extraordinarios. El sistema de productividad japonesa está organizado alrededor de este principio. Esta filosofía de la acción tiene por tanto un trasfondo minimalista: si queremos lograr algo mantenemos la meta a largo plazo, pero nos centramos en el siguiente paso: pequeño, gradual y en apariencia modesto. > Empecé a leer el libro hace unos años, pero me quedé en el primer capítulo por falta de tiempo. Tras leerlo me arrepiento de no haberme organizado mejor para hacerlo. Técnicas de cómo pensar sin despertar emociones de miedo que podrían paralizarnos o bloquearnos, haciéndonos preguntas pequeñas progresivas hacia nuestra meta. Pequeños cambios insignificantes que se adaptan fácilmente a nuestros hábitos diarios. Seguro que, como a mí, te hará rectificar muchas de las ideas preconcebidas de cómo conseguir tus metas, sea cual sea su ámbito. **Un libro muy recomendable. 8/10**

   
---

   
 ![](http://josecuellar.net/wp-content/uploads/leanux.jpg) Lean UX ofrece una perspectiva completa de cómo los principios de [Lean Startup](http://josecuellar.net/the-lean-startup-de-los-imprescindibles/) pueden aplicarse en un contexto de diseño de experiencia de usuario, conjugándolos con los clientes, design thinking y metodologías de desarrollo ágil de software. Nuevas técnicas y herramientas para conseguir una mayor colaboración entre distintos departamentos y entregas más rápidas. Un nuevo enfoque de desarrollo de experiencia de usuario evitando despilfarros y segundas fases de mejoras que nunca llegan. > Complemento idóneo a [Lean Startup](http://josecuellar.net/the-lean-startup-de-los-imprescindibles/). Me gusta como relaciona el diseño de producto, arquitectura de la información y usabilidad de usuario en el proceso de creación de producto mediante productos mínimamente viables y cómo abordar la progresión contínua de éstos mediantes experimentos de investiación y pruebas. Me ha interesado mucho conceptos como el BDUP (Big Design Up Front), el diseño colaborativo, el enfoque de adaptación al trabajo con scrum y los cambios aconsejables para implementar Lean UX en una organización. **Un libro muy recomendable tengas el perfil que tengas. 8/10**