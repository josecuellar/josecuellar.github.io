---
id: 740
title: 'Iniciación e implementación de Apache Solr'
date: '2016-05-30T21:03:25+00:00'
author: Jose
layout: revision
guid: 'http://www.josecuellar.net/general/514-revision-v1/'
permalink: '/?p=740'
---

Desde hace algunos meses he tenido la oportunidad de iniciarme en **Apache Solr**, realizando tareas de implementación, adaptación y configuración sobre una aplicación web de alto rendimiento con gran concurrencia de tráfico: *Todo un reto*.

<center>![](http://josecuellar.net/wp-content/uploads/solr.jpg)</center> Este hecho me ha permitido acercarme a la tecnología y dar mis primeros pasos en esta magnífica herramienta de búsqueda en la que cada día aprendo algo nuevo. [<span aria-label="Sigue leyendo Iniciación e implementación de Apache Solr">(más…)</span>](https://josecuellar.net/?p=740#more-740)