---
id: 1870
title: 'Inteligencia compartida. Bases para el trabajo en equipo: Las «5C».'
date: '2019-12-19T22:34:39+00:00'
author: Jose
layout: revision
guid: 'https://josecuellar.net/187-revision-v1/'
permalink: '/?p=1870'
---

- #### Complementariedad:
    
    Cada miembro domina y dispone de los conocimientos específicos de una parcela determinada del proyecto. > Todos somos muy ignorantes. Lo que ocurre es que no todos ignoramos las mismas cosas. [Albert Einstein](http://es.wikipedia.org/wiki/Albert_Einstein).
    
    Absolutamente nadie es capaz de dominar perfectamente todas las áreas de un proyecto. Compartir los conocimientos entre los miembros de un equipo es uno de los aspectos más importantes para la evolución profesional y para el beneficio general del proyecto. Si eres una persona que te motiva aprender y evolucionar profesionalmente, las críticas no te molestan (aprendiendo de ellas) y solicitas ayuda, sugerencias y alternativas en tu trabajo: Este punto no será un problema para tí. Sabes complementarte con los diferentes miembros del equipo. [<span aria-label="Sigue leyendo Inteligencia compartida. Bases para el trabajo en equipo: Las «5C».">(más…)</span>](https://josecuellar.net/?p=1870#more-1870)