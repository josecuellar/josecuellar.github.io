---
id: 864
title: 'The lean startup. De los imprescindibles'
date: '2015-09-18T20:30:34+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=864'
permalink: /the-lean-startup-de-los-imprescindibles/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - 'Lean startup'
    - 'Libros recomendados'
---

El método Lean Startup supone un nuevo enfoque que se está adoptando en todo el mundo para cambiar la forma en que las empresas crean y lanzan sus productos. Eric Ries define una startup como una organización dedicada a crear algo bajo condiciones de incertidumbre extrema. Prácticas pensadas para ayudar a los emprendedores a incrementar las probabilidades de crear una startup con éxito. No es una fórmula matemática infalible, sino una filosofía empresarial innovadora que ayuda a los emprendedores a escapar de las trampas del pensamiento empresarial tradicional. [<span aria-label="Sigue leyendo The lean startup. De los imprescindibles">(más…)</span>](https://josecuellar.net/the-lean-startup-de-los-imprescindibles/#more-864)