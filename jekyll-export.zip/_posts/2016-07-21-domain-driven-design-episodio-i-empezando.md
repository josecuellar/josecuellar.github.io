---
id: 1122
title: 'Domain-Driven Design. Empezando&#8230;'
date: '2016-07-21T22:26:20+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=1122'
permalink: /domain-driven-design-episodio-i-empezando/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Arquitectura
    - 'Domain-Driven Design'
---

Estoy inmerso en la lectura de "*Implementing Domain-Driven Design*" de Vaughn Vernon. Llevo algunos pocos capítulos y he decidido, a modo de seguimiento y aprendizaje, empezar a escribir una serie de post para compartir con la comunidad algunas reseñas de lo que creo interesante. Siéntete libre de hacer tus comentarios :)

<center>![](http://josecuellar.net/wp-content/uploads/ddd.jpg)</center>> El diseño no es sólo cómo se ve o cómo se siente. El Diseño es cómo funciona. Steve Jobs

 [<span aria-label="Sigue leyendo Domain-Driven Design. Empezando…">(más…)</span>](https://josecuellar.net/domain-driven-design-episodio-i-empezando/#more-1122)