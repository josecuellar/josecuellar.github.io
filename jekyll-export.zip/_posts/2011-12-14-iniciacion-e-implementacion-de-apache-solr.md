---
id: 514
title: 'Implementación de Apache Solr'
date: '2011-12-14T14:50:12+00:00'
author: Jose
layout: post
guid: 'http://www.josecuellar.net/?p=514'
permalink: /iniciacion-e-implementacion-de-apache-solr/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Arquitectura
    - NoSQL
    - Rendimiento
---

Desde hace algunos meses he tenido la oportunidad de realizar tareas de implementación, configuración, adaptación y transicion de consultas SQL sobre una aplicación web de alto rendimiento mediante Apache Solr.

<center>![](http://josecuellar.net/wp-content/uploads/solr.jpg)</center> Este hecho me ha permitido acercarme a la tecnología y dar mis primeros pasos en esta magnífica herramienta de búsqueda en la que cada día aprendo algo nuevo. [<span aria-label="Sigue leyendo Implementación de Apache Solr">(más…)</span>](https://josecuellar.net/iniciacion-e-implementacion-de-apache-solr/#more-514)