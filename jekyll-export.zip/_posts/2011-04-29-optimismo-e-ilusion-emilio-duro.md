---
id: 416
title: 'Optimismo e ilusión. Emilio Duró.'
date: '2011-04-29T10:04:03+00:00'
author: Jose
layout: post
guid: 'http://www.josecuellar.net/?p=416'
permalink: /optimismo-e-ilusion-emilio-duro/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Conferencias
    - Motivación
---

**Emilio Duró Pamies** es Licenciado en Ciencias Económicas por la Universidad Autónoma de Barcelona y Master en Administración de Empresas por ESADE. Ha sido Profesor Colaborador de distintas Universidades (La Fundación Universidad-Empresa de la Universidad de Navarra, Pompeu Fabra, Escuela de Negocios Caixanova e INEDE). Consejero Externo de RIOFISA y ADOLFO DOMINGUEZ. Así mismo ha sido Directivo de empresas de gran consumo como Martini Rossi y Yoplait-ATO. En la actualidad y desde hace más de 20 años trabaja como Consultor y Formador en empresas nacionales y multinacionales de diversos sectores desde ITER CONSULTORES la compañía que él fundó y da la que es su Consejero Delegado. <center> [![](http://farm6.static.flickr.com/5134/5506897610_34f59e5c1c.jpg)](http://www.flickr.com/photos/clavei/5506897610/ "Emilio Duró, en Flickr") </center> [<span aria-label="Sigue leyendo Optimismo e ilusión. Emilio Duró.">(más…)</span>](https://josecuellar.net/optimismo-e-ilusion-emilio-duro/#more-416)