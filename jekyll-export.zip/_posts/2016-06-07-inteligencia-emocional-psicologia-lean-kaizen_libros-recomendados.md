---
id: 895
title: 'Inteligencia emocional, Kaizen y Lean UX: libros recomendados'
date: '2016-06-07T20:08:06+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=895'
permalink: /inteligencia-emocional-psicologia-lean-kaizen_libros-recomendados/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - 'Lean UX'
    - 'Libros recomendados'
    - Motivación
    - SCRUM
---

En los últimos meses he tenido la oportunidad de leerme algunos libros. Quiero compartir con vosotros una pequeña reseña por cada uno, por si os pudiese servir de ayuda en la elección de vuestra próxima lectura. [<span aria-label="Sigue leyendo Inteligencia emocional, Kaizen y Lean UX: libros recomendados">(más…)</span>](https://josecuellar.net/inteligencia-emocional-psicologia-lean-kaizen_libros-recomendados/#more-895)