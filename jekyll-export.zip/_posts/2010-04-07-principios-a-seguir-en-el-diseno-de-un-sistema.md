---
id: 118
title: 'Principios básicos en el desarrollo de software'
date: '2010-04-07T11:11:30+00:00'
author: Jose
layout: post
guid: 'http://www.josecuellar.net/?p=118'
permalink: /principios-a-seguir-en-el-diseno-de-un-sistema/
description:
    - 'Principios a seguir en el diseño de un sistema. Implementar una arquitectura. Principios reconocidos por la industria del software.'
keywords:
    - 'arquitectura, diseño, sistema, principos, recomendaciones'
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Arquitectura
    - principios
    - solid
---

A la hora de diseñar y desarrollar software, es importante tener presente una serie de *principios de diseño fundamentales y básicos* que todo programador debería conocer y aplicar para desarrollar código limpio y de calidad.   
 [<span aria-label="Sigue leyendo Principios básicos en el desarrollo de software">(más…)</span>](https://josecuellar.net/principios-a-seguir-en-el-diseno-de-un-sistema/#more-118)