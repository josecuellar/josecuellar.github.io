---
id: 1914
title: 'Transactional Outbox &#038; Polling Publisher Patterns (2/3)'
date: '2020-04-24T00:02:05+00:00'
author: Jose
layout: post
guid: 'https://josecuellar.net/?p=1914'
permalink: /transactional-outbox-pattern-polling-publisher-pattern-2-3/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Arquitectura
---

A lo largo del tiempo las bases de datos *NoSQL* han ido mejorado sus características para ofrecernos *ACID* según el tipo (**Single Row, Single Shard o Distrituded**):

<figure class="wp-block-image size-large is-resized">![](https://josecuellar.net/wp-content/uploads/2020/04/image-21-1024x312.png)<figcaption>*Modern databases offer distributed ACID, Sid Choudhury*</figcaption></figure> [<span aria-label="Sigue leyendo Transactional Outbox & Polling Publisher Patterns (2/3)">(más…)</span>](https://josecuellar.net/transactional-outbox-pattern-polling-publisher-pattern-2-3/#more-1914)