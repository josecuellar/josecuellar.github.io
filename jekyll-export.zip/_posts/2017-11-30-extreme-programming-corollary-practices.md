---
id: 1635
title: 'Extreme Programming. Corollary Practices'
date: '2017-11-30T21:40:03+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=1635'
permalink: /extreme-programming-corollary-practices/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - agile
    - xp
---

This practices are dificult or dangerous to implement before completing the preliminary work of the primary practices. If you begin deploying daily, for example, without getting the defect rate down close to zero, you will have a disaster on your hands. Trust your nose about what you need to improve next. ![](https://josecuellar.net/wp-content/uploads/xppractices.JPG) [<span aria-label="Sigue leyendo Extreme Programming. Corollary Practices">(más…)</span>](https://josecuellar.net/extreme-programming-corollary-practices/#more-1635)