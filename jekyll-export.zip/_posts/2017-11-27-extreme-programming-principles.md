---
id: 1616
title: 'Extreme Programming. Principles'
date: '2017-11-27T22:29:56+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=1616'
permalink: /extreme-programming-principles/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - agile
    - xp
---

Principles may guide your team´s practices, but these are the prinnciples that guide XP:

<center>![](https://josecuellar.net/wp-content/uploads/xpprinciples.png)</center> [<span aria-label="Sigue leyendo Extreme Programming. Principles">(más…)</span>](https://josecuellar.net/extreme-programming-principles/#more-1616)