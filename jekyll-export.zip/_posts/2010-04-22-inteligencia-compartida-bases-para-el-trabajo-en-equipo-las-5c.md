---
id: 187
title: 'Inteligencia compartida. Bases para el trabajo en equipo: Las «5C».'
date: '2010-04-22T23:09:53+00:00'
author: Jose
layout: post
guid: 'http://www.josecuellar.net/?p=187'
permalink: /inteligencia-compartida-bases-para-el-trabajo-en-equipo-las-5c/
description:
    - 'Inteligencia compartida. Bases para el trabajo en equipo: Las '
keywords:
    - 'bases, complementariedad, coordinación, comunicación, confiana, compromiso, 5c, trabajo en equipo, inteligencia compartida'
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Motivación
---

- #### Complementariedad:
    
    Cada miembro domina y dispone de los conocimientos específicos de una parcela determinada del proyecto. > Todos somos muy ignorantes. Lo que ocurre es que no todos ignoramos las mismas cosas. [Albert Einstein](http://es.wikipedia.org/wiki/Albert_Einstein).
    
    Absolutamente nadie es capaz de dominar perfectamente todas las áreas de un proyecto. Compartir los conocimientos entre los miembros de un equipo es uno de los aspectos más importantes para la evolución profesional y para el beneficio general del proyecto. Si eres una persona que te motiva aprender y evolucionar profesionalmente, las críticas no te molestan (aprendiendo de ellas) y solicitas ayuda, sugerencias y alternativas en tu trabajo: Este punto no será un problema para tí. Sabes complementarte con los diferentes miembros del equipo. [<span aria-label="Sigue leyendo Inteligencia compartida. Bases para el trabajo en equipo: Las «5C».">(más…)</span>](https://josecuellar.net/inteligencia-compartida-bases-para-el-trabajo-en-equipo-las-5c/#more-187)