---
id: 47
title: 'El libro negro del emprendedor. No digas que nunca te lo advirtieron'
date: '2010-03-30T21:07:25+00:00'
author: Jose
excerpt: "Hace unos días acabé la lectura de <i>El libro negro del emprendedor. No digas que nunca te lo advirtieron.</i> De <b>Fernando Trías de Bes</b>. Un libro de fácil y rápida lectura. \r\n\r\nSe lo recomiendo a todas aquellas personas que quieran emprender una idea, a quienes la emprendieron, fracasaron y quieran volver a intentarlo, o simplemente quieran informarse de las verdades y riesgos que existen a la hora de emprender.\r\n"
layout: post
guid: 'http://www.josecuellar.net/?p=47'
permalink: /el-libro-negro-del-emprendedor-no-digas-que-nunca-te-lo-advirtieron/
description:
    - 'Valoración de lectura de: El libro negro del emprendedor. No digas que nunca te lo advirtieron. de Fernando Trías de Bes.'
keywords:
    - 'El libro negro del emprendedor,No digas que nunca te lo advirtieron, Fernando Trías de Bes, lectura, libro'
categories:
    - General
tags:
    - 'Libros recomendados'
---

Hace unos días acabé la lectura de *El libro negro del emprendedor. No digas que nunca te lo advirtieron.* De **Fernando Trías de Bes**. Un libro de fácil y rápida lectura. Se lo recomiendo a todas aquellas personas que quieran emprender una idea, a quienes la emprendieron, fracasaron y quieran volver a intentarlo, o simplemente quieran informarse de las verdades y riesgos que existen a la hora de emprender.

<center>![El libro negro del emprendedor. No digas que nunca te lo advirtieron.](http://www.josecuellar.net/wp-content/uploads/librosymanuales/14fcf_front.png)</center> [<span aria-label="Sigue leyendo El libro negro del emprendedor. No digas que nunca te lo advirtieron">(más…)</span>](https://josecuellar.net/el-libro-negro-del-emprendedor-no-digas-que-nunca-te-lo-advirtieron/#more-47)