---
id: 1685
title: 'Getting Started with ELK on Microsoft Azure'
date: '2018-12-05T21:18:41+00:00'
author: Jose
layout: post
guid: 'http://josecuellar.net/?p=1685'
permalink: /getting-started-with-elk-on-microsoft-azure/
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
categories:
    - General
tags:
    - Azure
    - ELK
    - Monitoring
---

Si estás familiarizado con el stack de ELK sabrás lo potente y versátil que resulta monitorizar cualquier tipo de actividad en cualquier infrastructura gracias a su potente motor de búsqueda Elasticsearch y las muchas posibilidades de personalización representando los datos que ofrece Kibana. Aunque opcional, la arquitectura recomendada para ELK debe incluir un broker entre los Beats y LogStash (Redis, Kafka o RabbitMQ) para evitar bottlenecks en la recuperación de datos de todos los orígenes que facilitan los beats: [![](https://josecuellar.net/wp-content/uploads/2018/11/elkredis.png)](https://josecuellar.net/wp-content/uploads/2018/11/elkredis.png) [<span aria-label="Sigue leyendo Getting Started with ELK on Microsoft Azure">(más…)</span>](https://josecuellar.net/getting-started-with-elk-on-microsoft-azure/#more-1685)