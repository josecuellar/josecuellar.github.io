---
id: 4
title: 'Sobre mí'
date: '2010-03-23T22:00:18+00:00'
author: Jose
layout: page
guid: 'http://www.josecuellar.net/?page_id=4'
description:
    - "Blog profesional de Jose Cuellar. Sobre mí, evolución y situación profesional actual. \r\nPresentación de mi blog y bienvenida."
keywords:
    - 'programación, aspnet, blog profesional, jose cuellar, microsoft, php, lamp, desarrollador, programador, project management, lead developer'
s4_url2s:
    - ''
s4_image2s:
    - ''
s4_ctitle:
    - ''
s4_cdes:
    - ''
---

<div style="float: left; margin-right: 20px; margin-bottom: 20px;">![](https://josecuellar.net/wp-content/uploads/2018/12/nPRozjTJ_400x400.jpg)</div>Más de veinte años liderando y desarrollando proyectos de diversa índole. <span style="font-size: revert; color: initial;">Experto en tecnologías Microsoft y Azure Cloud. </span><span style="font-size: inherit;">Me considero una persona cercana siempre con ganas de aprender y adaptarme a nuevos contextos. Me </span><span style="font-size: inherit;">apasiona la tecnología, la mejora continua y las personas.</span>Entiendo la tecnología como un medio y no un fin para crear y evolucionar productos que aporten un valor diferenciador al usuario. Hay que<span style="font-size: inherit;"> llegar los primeros, pero con la calidad necesaria que nos permita añadir valor progresivamente y manteniendo la motivación por seguir sintiéndonos orgullosos de lo que hacemos a lo largo del tiempo.</span>Después de trabajar mediante varias metodologías y observar el impacto y la evolución en el producto y el equipo: defiendo los valores y enfoques que aportan la **Agilidad, Lean Startup, Management 3.0 y XP**. Puedes contactar conmigo [aquí](http://josecuellar.net/contactar/) con total confianza :) Feedback is always welcome!